Huge thanks to [Notabirb1](https://www.planetminecraft.com/member/notabirb1/) for finishing Social Interactions Screen, Report Button, Check Box, Recipe Book and GUI Arrows textures and adding mod support for the next mods:

- Vanilla Notebook;
- No Chat Reports;
- MidnightControls;
- Capes;
